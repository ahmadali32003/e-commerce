import React, { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Main from './components/Main';

const App = () => {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <>
      <Header />

      <Main>
        {/* 1. Product Form */}
        {/* 2. Search Bar */}
        {/* 3. Product List with Add to Cart */}
        {/* 4. Cart + Checkout */}
      </Main>

      <Footer />
    </>
  );
};

export default App;
