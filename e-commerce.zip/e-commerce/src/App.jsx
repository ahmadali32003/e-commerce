import React, { useState } from "react";

const App = () => {
  const [cart, setCart] = useState([]);

  const products = [
    { id: 1, title: "Laptop", price: 1200 },
    { id: 2, title: "Phone", price: 800 },
    { id: 3, title: "Headphones", price: 150 },
    { id: 4, title: "Monitor", price: 300 },
  ];

  const handleAddToCart = (product) => {
    const exists = cart.find((item) => item.id === product.id);

    if (exists) {
      setCart(
        cart.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      );
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const total = cart.reduce(
    (acc, item) => acc + item.price * item.quantity,
    0
  );


  return (
    <div className="container my-4">
      {/* Navbar */}
      <nav className="navbar navbar-dark bg-dark px-3 mb-4">
        <span className="navbar-brand">🛒 My eCommerce</span>
        <span className="badge bg-success">Cart: {cart.length}</span>
      </nav>

      <div className="row">
        {/* Products Section */}
        <div className="col-md-8">
          <h4>Products</h4>
          <div className="row">
            {products.map((product) => (
              <div className="col-md-4 mb-3" key={product.id}>
                <div className="card">
                  <div className="card-body">
                    <h5>{product.title}</h5>
                    <p>Price: ${product.price}</p>
                    <button
                      className="btn btn-primary"
                      onClick={() => handleAddToCart(product)}
                    >
                      Add to Cart
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="col-md-4">
          <h4>Your Cart</h4>
          {cart.length === 0 ? (
            <p>No items in cart.</p>
          ) : (
            <>
              <ul className="list-group">
                {cart.map((item) => (
                  <li
                    key={item.id}
                    className="list-group-item d-flex justify-content-between"
                  >
                    <div>
                      {item.title} x {item.quantity}
                    </div>
                    <span>${item.price * item.quantity}</span>
                  </li>
                ))}
                <li className="list-group-item fw-bold d-flex justify-content-between">
                  <span>Total:</span>
                  <span>${total}</span>
                </li>
              </ul>

              {/* ✅ Clear Cart Button */}
              <button
                className="btn btn-danger mt-3 w-100"
                onClick={() => setCart([])}
              >
                Clear Cart
              </button>
            </>
          )}
        </div>

      </div>
    </div>
  );
};

export default App;
